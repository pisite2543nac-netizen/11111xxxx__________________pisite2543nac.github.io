// การเชื่อมต่อ Supabase สำหรับเว็บ GitHub Pages
// Publishable key สามารถเปิดเผยในเว็บฝั่งเบราว์เซอร์ได้เมื่อใช้ร่วมกับ RLS
window.APP_CONFIG = {
  SUPABASE_URL: 'https://dyaskotdutjycmoridfk.supabase.co',
  SUPABASE_ANON_KEY: 'sb_publishable_1v-hDRT2gkyr8rCVcnIFtg_CzINUEaU'
};
